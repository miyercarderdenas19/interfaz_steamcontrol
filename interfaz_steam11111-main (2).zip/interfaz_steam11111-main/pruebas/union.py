from tkinter import *
from tkinter import ttk, filedialog, messagebox
from PIL import ImageTk, Image
from werkzeug.utils import secure_filename

def browse_file(entry):
    # Implementa la lógica para buscar el archivo
    file_path = filedialog.askopenfilename()
    entry.delete(0, END)
    entry.insert(0, file_path)

def upload_file(entry):
    # Implementa la lógica para cargar el archivo
    file_path = entry.get()
    messagebox.showinfo("Información", f"Archivo {file_path} cargado con éxito.")

class Producto:
    def __init__(self, root_steamcontrol):
        self.root_steamcontrol = root_steamcontrol
        self.root_steamcontrol.title("steamcontrol")
        self.root_steamcontrol.iconbitmap("imagenes/steamcontrol.ico")
        self.root_steamcontrol.config(cursor="hand2")

        "--------------- Titulo --------------------"
        titulo = Label(root_steamcontrol, text="REGISTRO DE EQUIPOS", fg="black", font=("Comic Sans", 17, "bold"), pady=10)
        titulo.pack()

        "--------------- Logos productos --------------------"
        frame_logo_productos = LabelFrame(root_steamcontrol)
        frame_logo_productos.config(bd=0)
        frame_logo_productos.pack()

        # ... (Your logo code remains the same)

        "--------------- Frame marco --------------------"
        self.marco = LabelFrame(root_steamcontrol, text="Informacion del producto", font=("Comic Sans", 10, "bold"), pady=50)
        self.marco.pack()

        "--------------- Formulario --------------------"
        # ... (Your form code remains the same)

        "--------------- Frame botones --------------------"
        frame_botones = Frame(root_steamcontrol)
        frame_botones.pack()

        "--------------- Botones --------------------"
        boton_registrar = Button(frame_botones, text="REGISTRAR", command=self.Agregar_producto, height=2, width=10, bg="green", fg="white", font=("Comic Sans", 10, "bold"))
        boton_registrar.grid(row=0, column=1, padx=10, pady=15)

        "--------------- Tabla --------------------"
        self.tree = ttk.Treeview(height=10, columns=("columna1", "columna2"))
        self.tree.pack()

    def Agregar_producto(self):
        # Implementa la lógica para agregar un producto
        print("Archivo Agregado")

if __name__ == '__main__':
    root = Tk()
    root.title("Cargar Archivo")

    # Crear un cuadro de entrada y un botón para buscar archivos
    entry = Entry(root, width=40)
    entry.pack(pady=10)
    browse_button = Button(root, text="Buscar archivo", command=lambda: browse_file(entry))
    browse_button.pack(pady=5)

    # Crear un botón para cargar el archivo
    upload_button = Button(root, text="Cargar archivo", command=lambda: upload_file(entry))
    upload_button.pack(pady=5)

    ventana_producto = Producto(root)

    root.mainloop()

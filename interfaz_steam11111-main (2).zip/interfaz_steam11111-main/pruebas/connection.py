"""Archivo para hacer coneccion a la base de datos"""

import pyodbc

## Credenciales de acceso
server = ".\\"
database = "MantenimientoSteam"

## Crear cadena de conexion
connection_string = (
    f"DRIVER={{SQL Server}};SERVER={server};DATABASE={database};Trusted_Connection=yes;"
)


## Establece la conexion con la data base
def connection_database():
    try:
        conn = pyodbc.connect(connection_string)
        print("You have established connection with the database successfully...")

        ### Insertar datos de prueba

        ### Crear cursor para el query
        cursor = conn.cursor()

        ### Hacer consultas
        response = cursor.execute(
            "SELECT * FROM [dbo].[Descripcion]"
        ).fetchall()

        ### Mostrar informacion
        for item in response:
            print(f'{item.Detalles}   ')

        ### Cerrar conexion
        conn.close()
    except Exception as e:
        print(f"An error has been ocurred: {e} ")


## Main function
def main():
    connection_database()


if __name__ == "__main__":
    main()

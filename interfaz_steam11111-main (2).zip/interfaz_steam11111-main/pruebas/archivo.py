from tkinter import Tk, Entry, Button, filedialog, messagebox
from werkzeug.utils import secure_filename as secure_werkzeug_filename

class FileUploader:
    def __init__(self, root):
        self.root = root
        self.root.title("Cargar Archivo")

        # Tamaño de la ventana
        window_width = 600
        window_height = 400

        # Obtener la resolución de la pantalla
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()

        # Calcular la posición para centrar la ventana
        x_position = (screen_width // 2) - (window_width // 2)
        y_position = (screen_height // 2) - (window_height // 2)

        # Posicionar y redimensionar la ventana
        root.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")

        # Tamaño mínimo de la ventana
        root.minsize(400, 300)

        self.entry = Entry(root, width=40)
        self.entry.pack(pady=10)

        browse_button = Button(root, text="Buscar archivo", command=self.browse_file)
        browse_button.pack(pady=5)

        upload_button = Button(root, text="Cargar archivo", command=self.upload_file)
        upload_button.pack(pady=5)

    def browse_file(self):
        filename = filedialog.askopenfilename()
        self.entry.delete(0, "end")
        self.entry.insert(0, filename)

    def upload_file(self):
        filename = self.entry.get()
        if filename:
            try:
                with open(filename, "rb") as file:
                    content = file.read()
                secure_filename = secure_werkzeug_filename(filename)
                with open(secure_filename, "wb") as new_file:
                    new_file.write(content)
                messagebox.showinfo("Éxito", "Archivo cargado exitosamente")
            except Exception as e:
                messagebox.showerror("Error", str(e))
        else:
            messagebox.showerror("Error", "Por favor, selecciona un archivo")


if __name__ == "__main__":
    root = Tk()
    app = FileUploader(root)
    root.iconbitmap("imagenes\steamcontrol.ico")
    root.mainloop()